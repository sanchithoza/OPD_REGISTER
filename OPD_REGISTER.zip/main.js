const fastify = require("fastify")();
const path = require("path");

fastify.register(require("fastify-cors"), {
  origin: true,
});
fastify.get("/", function (req, reply) {
  reply.send("hello root");
});
fastify.register(require("./routes/opd"), { prefix: "/api/opd" });
module.exports = fastify;
